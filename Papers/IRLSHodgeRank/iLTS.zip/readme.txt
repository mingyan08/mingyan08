This is the code to reproduce the result in the paper. 

simulated.m is just 1 run of comparison of IRLS and LASSO.

realworlddata.m is the code to reproduce the results on the real-world datasets.