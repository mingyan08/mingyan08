clc;
clear;

addpath('Solvers')
addpath('realworlddata')
%%
% load the real-world dataset
dataset         = 'PC-VQA'; % PC-VQA or PC-IQA

if dataset == 'PC-VQA'
    input_filename  = 'data1.txt';   %data1.txt  for reference (a) in the PC-VQA dataset
elseif dataset == 'PC-IQA'
    input_filename  = 'data3_online.txt';   %data3_online.txt  for reference (c) in the PC-IQA dataset 
end

data_ref        = importdata(input_filename);

%%
% set the options (optional)
options.intercept   = 16;
options.beta1   = 0.75;  % beta1 < beta2 < 1 < beta3
options.beta2   = 0.8;  
options.beta3   = 1.03; 

%%
% Detect outliers using IRLSHodgerank
[score, output] = IRLSHodgerank(data_ref, options);

%% 
% Show the output
out             = output.outlier_detect(:,end);
outlier_detected= data_ref(out~=0,:);

Z = zeros(16,16);
for k = 1:size(outlier_detected,1)
    a = outlier_detected(k,:);
    Z(a(1),a(2)) = Z(a(1),a(2))+1;
end

if dataset == 'PC-VQA'
    index   = [1 9 10 13 7 8 11 14 15 3 12 4 16 5 6 2]; % ref1 ranking order returned by L2
elseif dataset == 'PC-IQA'
    index   = [1 8 16 2 3 11 6 12 9 14 5 13 7 10 15 4]; % ref3_online ranking order returnned by L2
end
% show the outlier detection
C   = Z(index,index);
printmat(C, 'Outliers', num2str(index), num2str(index))
% show the score 
disp([index' score(index)'])