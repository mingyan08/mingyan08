clc;
clear;

addpath('Solvers')

seed = 20140410;
par.seed = seed; %
if isfield(par,'seed')
    fprintf('Seed = %d\n',par.seed);
    RandStream.setGlobalStream(RandStream('mt19937ar','seed',par.seed));
end
N           = 16;
totalnum    = N * (N-1)/2;
data_ind    = zeros(totalnum,2);
k           = 0;
for i=1:N-1
    for j=i+1:N
        k   = k+1;
        data_ind(k,:) = [j i];
    end
end
outlier_ratio   = 0.1;
numsample       = 1000;

% we first create a random total order on $n$ candidates $V$ as the
% ground-truth and add paired comparison edges $(i,j)\in E$ to graph $G=(V,E)$ randomly, with the
% preference direction following the ground-truth order. To create sparse outliers,
% a random subset of $E$ is reversed in preference direction. In this way,
% we simulate a paired comparison graph, possibly incomplete and imbalanced, with outliers.
count       = 0;
data_ref    = zeros(numsample,2);
for i = 1:numsample
    aa      = ceil(totalnum * rand(1));
    p_re    = rand(1);
    if p_re < outlier_ratio %outlier_ratio binary reverse
       count    = count+1;
       data_ref(i,:) = data_ind(aa,2:-1:1);
    else
       data_ref(i,:) = data_ind(aa,:);
    end
end 

options.intercept   = N; 
options.beta1       = 0.75;  % 
options.beta2       = 0.8;  % 
options.beta3       = 1.03; % 
options.adaHodge    = false;

[score, output] = IRLSHodgerank(data_ref, options);

out = output.outlier_detect(:,end); %output the outlier
outlier_detected= data_ref(out ~= 0,:);

TP  = sum(outlier_detected(:,1) < outlier_detected(:,2));    
FP  = sum(outlier_detected(:,1) > outlier_detected(:,2));   
FN  = count - TP;    
P   = TP/(TP + FP);    
R   = TP/count;    
F1  = 2*P*R/(P + R);

outlier_detected_lasso=xqq_data(data_ref,count);
TP_lasso  = sum(outlier_detected_lasso(:,1) < outlier_detected_lasso(:,2));
FP_lasso  = sum(outlier_detected_lasso(:,1) > outlier_detected_lasso(:,2));    
FN_lasso  = count - TP_lasso;    
P_lasso   = TP_lasso/(TP_lasso + FP_lasso);    
R_lasso   = TP_lasso/count;    
F1_lasso  = 2*P_lasso*R_lasso/(P_lasso + R_lasso);

%%
% Compare the results 
Output = [TP, FP, FN, P, R, F1; TP_lasso, FP_lasso, FN_lasso, P_lasso, R_lasso, F1_lasso];
printmat(Output, 'comparison', 'IRLS LASSO','TP FP FN Precision Recall F1')